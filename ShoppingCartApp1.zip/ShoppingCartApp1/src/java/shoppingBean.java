/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.io.Serializable;
import java.util.HashMap;
import java.util.Set;
import java.util.TreeSet;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

/**
 *
 * @author 
 */
@ManagedBean( name="shoppingBean")
@SessionScoped
public class shoppingBean implements Serializable
{
private static final HashMap<String, String> booksMap= new HashMap<String, String>();
    
    static
    {
        booksMap.put("Girl","The Diary of Young Girl  :$45");
        booksMap.put("Cat","The Cat in the HAT  :$50");
        booksMap.put("Island","Treasure Island :$25");
        booksMap.put("boy","The Lost Boy :$52");
    }
    private Set<String> selections =new TreeSet< String>();
    private String selection;
    public int cost =0;
    public int costa,costb,costc,costd;
    
    public int getNumberOfSelections()
    {
        return selections.size();
    }
    public String getSelection()
    {
        return selection;
    }
    public void setSelection( String topic)
    {
        selection = booksMap.get(topic);
        if(selection == "The Diary of Young Girl  :$45")
        {
            costa = 45;
            cost =cost+costa;
        }
        if(selection == "The Cat in the HAT  :$50")
        {
            costb = 50;
            cost =cost+costb;
        }
        if(selection == "Treasure Island :$25")
        {
            costc = 25;
            cost =cost+costc;
        }
        if(selection == "The Lost Boy :$52")
        {
            costd = 52;
            cost =cost+costd;
        }
        selections.add( selection);
    }
    
    public String[] getSelections()
    {
        return selections.toArray(new String[ selections.size()]);
    }
    public int getCost()
    {
        return cost;
    }
   
}
